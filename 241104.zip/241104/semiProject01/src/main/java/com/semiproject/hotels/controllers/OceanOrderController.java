package com.semiproject.hotels.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OceanOrderController {

	@GetMapping("/standard1")
    public String standard1() {
        return "oceanorder/standard1";  
    }
	
	@GetMapping("/standard2")
    public String standard2() {
        return "oceanorder/standard2";  
    }
	
	@GetMapping("/standard3")
    public String standard3() {
        return "oceanorder/standard3";  
    }
	
	@GetMapping("/deluxe1")
    public String deluxe1() {
        return "oceanorder/deluxe1";  
    }
	
	@GetMapping("/deluxe2")
    public String deluxe2() {
        return "oceanorder/deluxe2";  
    }
	
	@GetMapping("/deluxe3")
    public String deluxe3() {
        return "oceanorder/deluxe3";  
    }
	
	@GetMapping("/premium1")
    public String premium1() {
        return "oceanorder/premium1";  
    }
	
	@GetMapping("/premium2")
    public String premium2() {
        return "oceanorder/premium2";  
    }
	
	@GetMapping("/premium3")
    public String premium3() {
        return "oceanorder/premium3";  
    }
}
