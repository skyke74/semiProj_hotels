package com.semiproject.hotels.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PoolOredrController {

	@GetMapping("/postandard1")
    public String postandard1() {
        return "poolorder/postandard1";  
    }
	
	@GetMapping("/postandard2")
    public String postandard2() {
        return "poolorder/postandard2";  
    }
	
	@GetMapping("/postandard3")
    public String postandard3() {
        return "poolorder/postandard3";  
    }
	
	@GetMapping("/podeluxe1")
    public String podeluxe1() {
        return "poolorder/podeluxe1";  
    }
	@GetMapping("/podeluxe2")
    public String podeluxe2() {
        return "poolorder/podeluxe2";  
    }
	@GetMapping("/podeluxe3")
    public String podeluxe3() {
        return "poolorder/podeluxe3";  
    }
	@GetMapping("/popremium1")
    public String popremium1() {
        return "poolorder/popremium1";  
    }
	@GetMapping("/popremium2")
    public String popremium2() {
        return "poolorder/popremium2";  
    }
	@GetMapping("/popremium3")
    public String popremium3() {
        return "poolorder/popremium3";  
    }
}
